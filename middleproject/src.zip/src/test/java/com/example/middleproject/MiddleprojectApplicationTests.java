package com.example.middleproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiddleprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
